// pages/find/newArticleModify/newArticleModify.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    details: {
      id: 1,
      title: '【报名开启】朋友圈本地推广分享会强势来袭',
      details: '本地商户推广越来越找不到门道儿?获客越来越难?成本越来越高?面临的难题也越来越多',
      content: '广联先锋隶属于北京全时天地在线网络信息股份有限公司，专注为业提供互联网营销服务，累计服务客户超过10000家，团队规模突破500人是国内最具规模和品牌影响力的互联网综合服务机构。并为客户量身定制广告投放方案，提供投放策略、文案创意、账户搭建、投放执行、数据分析、账户优化等一站式广告服务，让您投放无忧。'
    }

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})